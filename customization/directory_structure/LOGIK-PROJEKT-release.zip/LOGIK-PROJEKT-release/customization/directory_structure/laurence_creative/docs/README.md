LOGIK-PROJEKT changelist for Laurence Creative

.
├── docs
│   └── README.md
├── modules
│   └── functions
│       └── synchronize
│           └── sync_editorial_tree_premiere.py
├── README.md
└── resources
    ├── cfg
    │   └── projekt_configuration
    │       └── tree
    │           └── projekt
    │               └── assets.json
    └── flame
        └── python
            └── logik_projekt
                └── projekt_tools
                    └── logik_projekt_layout
                        └── config
                            └── library_template_04.json

15 directories, 5 files
