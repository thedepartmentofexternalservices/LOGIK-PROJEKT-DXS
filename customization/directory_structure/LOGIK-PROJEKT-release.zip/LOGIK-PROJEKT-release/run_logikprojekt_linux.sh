#!/bin/bash
cd /home/randy/workspace/LOGIK-PROJEKT-release
/opt/Autodesk/python/2025.2.2/bin/python /home/randy/workspace/LOGIK-PROJEKT-release/logik_projekt.py
